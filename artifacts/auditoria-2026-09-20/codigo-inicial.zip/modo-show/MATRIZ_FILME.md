# Matriz F01–F44 — o que o filme mostra × o que esta instalação faz

Esta matriz responde ao prompt mestre de 19/09/2026 (§3 e §19). Ela **não substitui**
`INVENTARIO.md`: aquela matriz continua valendo e descreve a origem de cada função. Esta
aqui olha pelos 44 comportamentos pedidos e diz, item por item, o que existe, onde está no
código, qual evidência eu tenho e o que falta.

## Como ler o estado

| Sigla | Significa | Regra que eu sigo |
|---|---|---|
| **EP** | existente preservado | já existia e continua funcionando; não foi reescrito |
| **IT** | implementado e testado ponta a ponta | teste automatizado **e** execução real registrada nesta instalação |
| **TP** | testes parciais ou simulados | o código existe e tem teste, mas com dublê (mock), fixture ou sem o caminho real completo |
| **AD** | aguardando dado, conta ou permissão | falta algo do Senhor (chave, conta, aparelho, ficar na frente da câmera) |
| **PD** | pendente | não existe ainda; está aqui para ser feito |
| **AJ** | adaptado com justificativa | existe um equivalente útil, diferente do filme, e o porquê está escrito |
| **FE** | fora do escopo operacional | ficção sem equivalente pedido (§3-H do prompt) |

Uma coisa que eu **não** faço nesta matriz: chamar de IT o que só tem teste com dublê.
"O endpoint existe" não é integração funcionando.

Data desta revisão: **19/09/2026, 23h40**. Testes: 402 no HUD (3 pendentes marcados), 90 no OpenJarvis.

---

## A. Conversa, personalidade e colaboração

| ID | Comportamento pedido | Equivalente nesta instalação | Evidência | Limite honesto | Estado |
|---|---|---|---|---|---|
| F01 | Diálogo natural, sem depender de frases fixas | `comandos.py` (regras) + `fala_variantes.py` (variações da fala) + modelo local quando nada casa | test_fala_variantes: 44 formas de pedir + 7 frases parecidas que **não** podem virar comando; real: "memore o meu rosto" e "memorize seu rosto" executam | a bateria de variações cobre hoje **cadastro de rosto/voz**; as outras famílias ainda dependem das regras fixas + modelo. Próximo alvo: mesma bateria para lembretes, listas e mídia | TP |
| F02 | "a segunda", "aumente isso", "continue" | `contexto.py:continuar()` + `comandos.ultima_lista` (agora com validade de 10 min: "abra a segunda" logo após as manchetes é a **notícia**, não um programa chamado "segunda") + peça ativa em `pecas.py` ("aumente a largura em 2 mm"; sem dimensão, **pergunta**) | test_consultas, test_novidades, test_pecas (15), test_aceitacao T03/T23; real: "aumente isso" → "Qual dimensão, Senhor?" | "continue" ainda não retoma leitura de texto longo | IT |
| F03 | Continuidade de atividade (documento, peça, projeto) | `projetos.py`: tarefa com objetivo, condição de conclusão, etapas, resultados, aprovações e 10 estados; comandos "comece o projeto", "falta…", "o que falta?", "pause", "continue de ontem", "terminei"; cartão no Painel | test_projetos (20) + test_aceitacao T02/T05/T06; **real**: projeto criado, peça alterada, runtime reiniciado e "o que falta?" respondeu certo | não separa requisitos de restrições ainda; não há dependência entre tarefas | IT |
| F04 | Perguntar quando há duas leituras possíveis | perguntas pontuais ("A que horas, Senhor?", "Qual dimensão?") | test_lembretes | é caso a caso, não uma regra geral de ambiguidade | TP |
| F05 | Discordar com fundamento | — | — | não existe. O modelo pode discordar por conta própria, o que não é a mesma coisa | PD |
| F06 | Tratamento, personalidade estável, humor discreto | `preferencias.nome_usuario` + `SISTEMA_NATURAL` em `voz.py` | real: trata por "Senhor" em toda resposta | — | EP |

## B. Assistência cotidiana e informações

| ID | Comportamento pedido | Equivalente nesta instalação | Evidência | Limite honesto | Estado |
|---|---|---|---|---|---|
| F07 | Resumo do início do dia | `secretario.py` (resumo do dia: hora, clima, agenda, lembretes, notícias) | test_secretario (22); real: resumo falado no boot | agenda do Google é leitura e depende de conexão; sem ela, o resumo **diz** que está sem agenda | IT |
| F08 | Hora, fuso, cidade, dados atuais com fonte | `utilidades.py` + `clima.py` + `cotacoes.py` | test_consultas (18); real: hora mundial e clima citando a fonte | — | IT |
| F09 | Notícias com fontes e sem repetir | `noticias.py` | test_novidades (22); real: manchetes lidas com fonte | — | IT |
| F10 | Recuperar compromissos, mensagens e decisões | `memoria.py`, `tarefas.py`, `agenda.py`, `rascunhos.py` | test_memoria, test_secretario, test_rascunhos | mensagens ficam em rascunho, sem envio (limite preservado de propósito) | EP |
| F11 | Informação em painel enquanto fala | cartão de contexto (`estado.contexto` → `hud/jarvis.js`) | captura real da tela Jarvis | — | IT |
| F12 | Apoio administrativo (reunião, pendências, resumo, rascunho) | `secretario.py`, `documentos.py`, `rascunhos.py`, `agenda_analise.py` | test_secretario, test_arquivos | preparar reunião ainda é manual: não junta sozinho documentos + agenda + pendências num pacote | TP |

## C. Visão, percepção e investigação

| ID | Comportamento pedido | Equivalente nesta instalação | Evidência | Limite honesto | Estado |
|---|---|---|---|---|---|
| F13 | Localizar e contar sem duplicar | `deteccao.py` (YOLOX-S int8, 80 categorias) + `percepcao.py` | test_visao_tempo_real, test_percepcao; real: detecções desenhadas na câmera | contagem é por quadro estável (≥55% em 2 de 3 quadros), não por identidade rastreada | IT |
| F14 | Acompanhar movimento, oclusão, reaparição | `rastreador.py`: casa as caixas entre quadros por sobreposição + classe + tamanho; identificador **temporário** ("obj3"); objeto tapado fica "sumido" 6 s e pode voltar; **na dúvida nasce id novo** | test_rastreador (12) + test_aceitacao T13; ligado à `VisaoContinua` | os ids não sobrevivem ao reinício, de propósito: identidade que dura exige cadastro (§9) | IT |
| F15 | Responder sobre o que está sendo observado | `visao.py` + conversa visual em `voz.py` | test_conversa_visao (9); real: pergunta visual vai com a imagem | — | IT |
| F16 | Reconstruir uma cena consultável | `rastreador.py` (o que está/esteve em vista, com hora e lado) + `inventario.py` (objetos do Senhor com última observação) + `olhar.py`/`regua.py` | test_rastreador, test_inventario (15), T14 | é consulta por objeto, não um mapa da cena; nada de reconstrução métrica 3D | TP |
| F17 | Cruzar ocorrências por período/local/atributo | — | — | depende de F16 e do inventário pessoal. Pendente | PD |
| F18 | Separar o que foi observado do que se pode fazer | texto de capacidades no prompt + respostas dos comandos | real: o Jarvis executa em vez de recusar | a separação é por redação, não por estrutura de dados | TP |

## D. Engenharia e oficina

| ID | Comportamento pedido | Equivalente nesta instalação | Evidência | Limite honesto | Estado |
|---|---|---|---|---|---|
| F19 | Examinar projetos, versões e parâmetros | `pecas.py`: acervo com parâmetros de origem, versões numeradas, arquivo por versão e volume medido; "quais versões?", "volte para a versão 1" | test_pecas (15) + test_engenharia; **real**: caixa v1 e v2 no disco, versões faladas | ainda não guarda requisitos do projeto nem materiais por peça | IT |
| F20 | Vista explodida / separar componentes | — | — | exige estrutura de montagem, que não existe. Pendente | PD |
| F21 | Alterar parâmetro com prévia e reversão | `Pecas.alterar()` valida antes (unidades, relações, espessura mínima de 0,8 mm, mesa de 300 mm), gera **versão nova** e mantém a anterior; `reverter()` volta criando outra versão | test_pecas + test_aceitacao T25; real: "aumente a largura em 2 milímetros" → v2 com volume medido | a prévia é o modelo na mesa holográfica, não um antes/depois lado a lado | IT |
| F22 | Registrar experimentos, medidas e falhas | etapas da tarefa guardam resultado **e falha** (`falhar_etapa`), e o estado vira "parcialmente concluída"; as versões da peça guardam o que mudou e o volume medido | test_projetos + test_aceitacao T27 | não guarda condições do experimento (temperatura, material do rolo) | TP |
| F23 | Calcular e simular com unidades e hipóteses | `engenharia.py` (elétrica, física, consumo, peso) | test_engenharia; real: contas faladas com unidade | é cálculo analítico e **se apresenta como tal**, nunca como simulação avançada | IT |
| F24 | Comparar alternativas de material | `engenharia.MATERIAIS` (19 materiais) | test_engenharia; real: comparação falada | massa é teórica (densidade × volume) e é dita como teórica | IT |
| F25 | Recuperar conhecimento anterior (manuais, decisões) | `documentos.py` + memória do OpenJarvis | test_arquivos | sem RAG ligado aos manuais do Senhor: a base de documentos está **vazia** (0 documentos, conferido em 19/09) | PD |
| F26 | Comunicar limites do que foi calculado | redação dos comandos de engenharia | real: "massa teórica" aparece na fala | não há campo estruturado de hipótese/limite por resultado | TP |

## E. Diagnóstico, telemetria e assistência operacional

| ID | Comportamento pedido | Equivalente nesta instalação | Evidência | Limite honesto | Estado |
|---|---|---|---|---|---|
| F27 | Energia e disponibilidade | `sistema.py` + `telemetria.py` + comando de consumo | test_runtime, test_monitores; real: bateria, CPU e memória no painel | consumo por programa é **estimativa** e aparece rotulado | IT |
| F28 | Falhas de componentes | `boot.py` + registro de eventos | real: "Memória quase cheia: 96%", "servidor parou de responder", "modelo não respondeu" | — | IT |
| F29 | Condições anormais com limite configurado | `monitores.py` | test_monitores (10) | sem sensores físicos: só o que o Windows expõe | IT |
| F30 | Diagnóstico contextualizado (o que depende do quê) | eventos por tipo (`voz`, `camera`, `servidor`…) | real no painel | não diz **quais tarefas** ficam bloqueadas por aquela falha | TP |
| F31 | Posição e navegação | — | — | sem fonte autorizada de localização. Não invento GPS | AD |
| F32 | Dados fisiológicos | — | — | **não implemento** diagnóstico médico por webcam. Fonte ausente = recurso indisponível (§3-F32) | FE |

## F. Computadores, interfaces e comunicação

| ID | Comportamento pedido | Equivalente nesta instalação | Evidência | Limite honesto | Estado |
|---|---|---|---|---|---|
| F33 | Preferências e identidade compartilhadas | `preferencias.py` + `estado.py` difundido por SSE | test_runtime; real: mudança no painel aparece nas telas | — | IT |
| F34 | Intermediar comunicações | `telegram.py` (ponte com pareamento), `rascunhos.py`, link do WhatsApp | test_casa_comunicacao (8) | **aguarda o token do bot**; WhatsApp é envio manual por link, de propósito | AD |
| F35 | Filtrar interrupções | `notificacoes.py` + `anunciador.py` (sob demanda / assistido / proativo) | test_novidades, test_lembretes | falta considerar "atividade atual" (foco) como critério | TP |
| F36 | Interfaces consistentes | estado único em `estado.py`; telas e chat leem o mesmo SSE | test_widgets (12); real: painel e tela Jarvis em sincronia | — | IT |
| F37 | Canais e clientes com capacidades declaradas | `ponte.py` + token por instância + pareamento do Telegram | test_instancia_unica | não há declaração formal de capacidades por canal | TP |
| F38 | Transferir a apresentação para outra tela | `holograma.py` + `monitores()` (mesa em outro monitor) | test_engenharia; real: gráfico e peça na mesa | não confirma "sucesso observável" no destino | TP |

## G. Autonomia, paralelismo e protocolos

| ID | Comportamento pedido | Equivalente nesta instalação | Evidência | Limite honesto | Estado |
|---|---|---|---|---|---|
| F39 | Trabalho persistente enquanto o Senhor faz outra coisa | threads de `rotinas.py`, `monitores.py`, `secretario.py`, vigia da câmera | test_rotinas, test_automacao | o trabalho **não é retomável**: se o runtime reinicia, a tarefa em andamento se perde. Pendente (T06) | TP |
| F40 | Protocolos nomeados e parametrizados | `protocolos.py` (criar, listar, executar, apagar; lista de comandos proibidos) | test_automacao (10); real: protocolo criado e executado | sem parâmetros por execução ainda | IT |
| F41 | Coordenar operações respeitando dependências | execução sequencial dos passos do protocolo | test_automacao | não há grafo de dependências nem paralelismo controlado | TP |
| F42 | Avisar conclusão, resultado e bloqueio | `anunciador.py` | test_lembretes; real: lembretes falados | — | IT |
| F43 | Recuperar-se de falhas | modelo reserva (`modelos_ia.py`), religar servidor, queda de voz remota para Kokoro | test_modelo_reserva (10); real: troca anunciada de gemma4 → qwen3.5 | recuperação é por caminho, não por tarefa: não retoma de onde parou | TP |
| F44 | Supervisionar componentes e recuperar tarefas | `boot.py`, instância única, `/api/servidor/religar` | test_instancia_unica; real: servidor religado pelo painel | **respeita "pare"**: parar sempre vence. Sem retomada auditável de tarefa ainda | TP |

## H. Elementos extraordinários da ficção (§3-H)

| ID | No filme | Nesta instalação | Estado |
|---|---|---|---|
| — | Pilotar armadura, combate, armamentos, coordenar unidades | **Não viram ferramenta.** O equivalente preservado é diagnóstico de sistema ("prepare a armadura" = checagem de energia, rede, modelos e serviços) | AJ |
| — | Protocolos destrutivos (ex.: House Party) | Protocolos existem, mas `protocolos.PROIBIDOS` bloqueia comandos destrutivos | AJ |
| — | JARVIS virar o Visão | Sem equivalente. Não há autorreplicação, invasão nem resistência a desligamento | FE |
| — | Onisciência / consciência | Sem equivalente; não prometo | FE |

---

## Identificação fina e inventário (§8 e §9 do prompt)

| Requisito | O que existe agora | Evidência | Limite honesto | Estado |
|---|---|---|---|---|
| §8 sequência selecionar → avaliar → classificar → extrair pistas → consultar → comparar → esclarecer → responder | `identificacao.py` (regras da decisão) + `visao.identificar()` (a câmera e o modelo de visão local) + `Visao.INSTRUCAO_IDENT`, que pede **pistas separadas** (categoria, texto lido, logotipo) em vez de um veredito | test_identificacao (15) + T08, T09, T10, T11 | o "catálogo" hoje é o inventário do Senhor; não consulta fabricante na internet. O texto é lido pelo modelo de visão, não por OCR dedicado | TP |
| §8 qualidade da imagem barra palpite | `avaliar_regiao()` mede nitidez (laplaciano), brilho, tamanho em pixels e corte na borda; imagem ruim **não** produz marca | test_identificacao (5 casos) | limiares calibrados a olho, não contra um conjunto de fotos rotuladas | TP |
| §8 evidência por atributo | cada atributo carrega valor, estado (confirmado, compatível, provável, conflitante, não determinado), fonte e data; duas evidências que discordam viram **conflito**, não "a mais nova ganha" | test_identificacao | — | IT |
| §8 ambiguidade preservada | dois candidatos com a mesma força continuam dois, e o Jarvis pede a etiqueta | T10 | — | IT |
| §9 inventário pessoal | `inventario.py`: objeto com nome, apelidos, categoria, marca, modelo, manual, atributos confirmados e observações; separa **modelo de produto** de **unidade física**; comandos "cadastre esta impressora", "a marca da impressora é Epson", "o que você sabe sobre a minha impressora", "abra o manual", "esqueça a minha impressora" | test_inventario (15) + T12; real: cadastro, confirmação e consulta respondendo | sem foto por padrão (e só se o Senhor mandar); não liga sozinho um objeto visto a um cadastro — isso exige confirmação | IT |
| §9 última observação ≠ estado atual | `falar_objeto()` e `falar_ultima_vez()` sempre dizem quando e onde vi, e que **não sei se ainda está lá** | test_inventario, test_rastreador, T14 | — | IT |

## Cenários de aceitação T01–T34

`testes/test_aceitacao.py` tem um teste por cenário, com o texto do cenário no
corpo. Hoje: **32 passando, 3 pendentes** (marcados como pulados, com o motivo):

- **T17** — análise de vídeo informando os trechos realmente analisados.
- **T18** — rastreamento de mãos (S7): gesto e mouse selecionando o mesmo elemento.
- **T20** — manual atualizado não deixar a resposta usar a versão antiga em silêncio.

## Resumo honesto do diagnóstico

| Estado | Itens | Antes (20h30) |
|---|---|---|
| IT (testado ponta a ponta) | F02, F03, F07, F08, F09, F11, F13, F14, F15, F19, F21, F23, F24, F27, F28, F29, F33, F36, F40, F42 — **20** | 15 |
| EP (existente preservado) | F06, F10 — **2** | 2 |
| TP (parcial ou simulado) | F01, F04, F12, F16, F18, F22, F26, F30, F35, F37, F38, F39, F41, F43, F44 — **15** | 15 |
| AD (aguarda algo do Senhor) | F31, F34 — **2** | 2 |
| PD (pendente, a fazer) | F05, F17, F20, F25 — **4** | 9 |
| AJ / FE (adaptado ou ficção) | armadura, protocolos destrutivos, Visão, onisciência, F32 — **5** | 5 |

**O que foi feito desde o diagnóstico das 20h30** (nesta ordem):

1. ✔ **F03 + F02** — estado de projeto/tarefa e peça ativa. Destravou T02, T03, T05, T06, T23.
2. ✔ **F21 + F19 + F22** — peça com parâmetros, versões e validação. Destravou T25, T26, T27.
3. ✔ **F14** — rastreador com identidade temporária. Destravou T13.
4. ✔ **§8 + §9** — identificação com evidência e inventário pessoal. Destravou T08, T09, T10, T12, T14.

**O que continua pendente**, na ordem em que vale a pena atacar:

1. **F25 + T20** — manuais e documentos do Senhor indexados, com versão (a base de documentos do OpenJarvis está **vazia**: 0 documentos, conferido em 19/09). É o que falta para o Jarvis responder pelo manual da impressora dele.
2. **F17** — cruzar ocorrências (o que vi, quando, onde) por período e atributo.
3. **F20** — vista explodida, que exige estrutura de montagem das peças.
4. **F05** — discordância fundamentada de verdade (hoje só o modelo discorda, o que não é a mesma coisa).
5. **T17 e T18** — cobertura declarada na análise de vídeo e rastreamento de mãos (S7).
