"""Laço limitado de ferramentas: validar, executar, devolver evidências ao modelo."""
from __future__ import annotations

import json
import time
import uuid


def validar_argumentos(nome: str, args, ferramentas: list[dict]) -> str | None:
    spec = next((t["function"]["parameters"] for t in ferramentas if t["function"]["name"] == nome), None)
    if spec is None:
        return "ferramenta desconhecida"
    if not isinstance(args, dict):
        return "argumentos devem ser um objeto"
    props = spec.get("properties", {})
    if set(args) - set(props):
        return "parâmetros desconhecidos"
    if any(k not in args for k in spec.get("required", [])):
        return "parâmetro obrigatório ausente"
    tipos = {"string": str, "integer": int, "boolean": bool, "number": (int, float)}
    for k, value in args.items():
        p = props[k]
        tipo = tipos.get(p.get("type"))
        if tipo and (not isinstance(value, tipo) or (p.get("type") in {"integer", "number"} and isinstance(value, bool))):
            return f"tipo inválido em {k}"
        if isinstance(value, str) and (not value.strip() or len(value) > 8000):
            return f"texto vazio ou excessivo em {k}"
        if "enum" in p and value not in p["enum"]:
            return f"valor não permitido em {k}"
        if "minimum" in p and value < p["minimum"] or "maximum" in p and value > p["maximum"]:
            return f"valor fora do limite em {k}"
    if nome == "volume" and len(args) != 1:
        return "informe somente percentual, mudo ou ajuste"
    if nome == "criar_lembrete" and bool(args.get("em_minutos")) == bool(args.get("horario")):
        return "informe em_minutos OU horario"
    return None


def executar_plano(primeira: dict, pedido: dict, consultar, executar, cancelado,
                   registrar, *, max_passos: int = 5, prazo_s: float = 180) -> tuple[str | None, list[dict]]:
    """Returns actual results even when the final model summary fails.

    The budget includes invalid calls. A repeated call cannot repeat a write.
    No fallback model may replay a partially executed plan.
    """
    inicio = time.monotonic()
    mensagens = list(pedido["messages"])
    ferramentas = pedido.get("tools", [])
    msg, passos, vistos, resultados = primeira, 0, {}, []
    rastros = []
    encerrado = ""
    while msg.get("tool_calls"):
        if cancelado.is_set():
            return None, rastros
        chamadas = msg["tool_calls"]
        if not isinstance(chamadas, list):
            resultados.append("O modelo retornou chamadas inválidas; interrompi o plano.")
            break
        chamadas = chamadas[:max_passos - passos]
        if not chamadas or time.monotonic() - inicio > prazo_s:
            break
        assistant = {"role": "assistant", "content": msg.get("content") or "", "tool_calls": []}
        for chamada in chamadas:
            if not isinstance(chamada, dict):
                encerrado = "O modelo retornou uma chamada inválida; interrompi o plano."
                continue
            f = chamada.get("function") or {}
            if not isinstance(f, dict):
                encerrado = "O modelo retornou argumentos de função inválidos; interrompi o plano."
                continue
            assistant["tool_calls"].append({"id": str(chamada.get("id") or uuid.uuid4().hex),
                "type": "function", "function": {"name": str(f.get("name") or ""),
                "arguments": f.get("arguments") if isinstance(f.get("arguments"), str) else json.dumps(f.get("arguments") or {})}})
        if not assistant["tool_calls"]:
            resultados.append(encerrado or "O modelo retornou chamadas inválidas; interrompi o plano.")
            break
        mensagens.append(assistant)
        rastros.append(assistant)
        for chamada in assistant["tool_calls"]:
            if cancelado.is_set():
                return None, rastros
            if time.monotonic() - inicio >= prazo_s:
                encerrado = "O prazo deste pedido acabou; preservei os resultados anteriores."
                break
            f = chamada["function"]
            passos += 1
            try:
                args = json.loads(f["arguments"])
                erro = validar_argumentos(f["name"], args, ferramentas)
            except (ValueError, TypeError):
                args, erro = {}, "JSON inválido"
            assinatura = json.dumps([f["name"], args], sort_keys=True, ensure_ascii=False)
            if erro:
                resultado = "Não executei: " + erro + "."
            elif assinatura in vistos:
                resultado = "Chamada repetida; resultado anterior: " + vistos[assinatura]
            else:
                try:
                    resultado = executar(f["name"], args)
                    resultado = str(resultado) if resultado is not None else "Ferramenta sem resultado verificável."
                except Exception as exc:
                    resultado = f"A ferramenta falhou ({type(exc).__name__}); confira o estado antes de repetir."
                vistos[assinatura] = resultado
            registrar("comando", f"ferramenta {passos}/{max_passos}: {f['name']}")
            resultados.append(resultado)
            evento = {"role": "tool", "tool_call_id": chamada["id"], "content": resultado}
            mensagens.append(evento)
            rastros.append(evento)
        if cancelado.is_set():
            return None, rastros
        if encerrado or passos >= max_passos or time.monotonic() - inicio >= prazo_s:
            break
        try:
            proximo = dict(pedido, messages=mensagens, stream=False)
            dados = consultar(proximo)
            msg = (dados.get("choices") or [{}])[0].get("message") or {}
            if not isinstance(msg, dict):
                encerrado = "O modelo devolveu uma resposta inválida; preservei os resultados das ferramentas."
                break
        except Exception:
            resultados.append("As ferramentas responderam, mas não consegui concluir a revisão pelo modelo.")
            break
    if passos >= max_passos and msg.get("tool_calls"):
        resultados.append("Atingi o limite de cinco chamadas deste pedido; confira os resultados antes de continuar.")
    if encerrado:
        resultados.append(encerrado)
    # Evidence is authoritative; generated claims never replace tool results.
    return " ".join(resultados) or None, rastros
