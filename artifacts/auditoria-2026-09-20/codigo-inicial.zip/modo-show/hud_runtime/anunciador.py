"""Falas proativas: o Jarvis toma a palavra sozinho, como no filme.

"Senhor, sua reuniao comeca em 10 minutos." / "Bem-vindo de volta, Senhor."
Espera a vez: nunca fala por cima de voce nem de outra resposta. No horario
de silencio (preferencia) so fala o que voce mesmo pediu (lembretes, timers).

Tres modos (preferencia "modo_proativo"), por categoria de fala:
- sob_demanda: so o que voce pediu (lembretes, timers, seus monitores);
- assistido (padrao): + compromissos, boas-vindas/resumo do dia, avisos criticos;
- proativo: + observacoes (e-mail novo, alguem na sala).
"""

from __future__ import annotations

import queue
import threading
import time
from datetime import datetime
from typing import Any, Callable


PERMITIDAS = {
    "sob_demanda": {"pedido"},
    "assistido": {"pedido", "agenda", "presenca", "aviso"},
    "proativo": {"pedido", "agenda", "presenca", "aviso", "observacao"},
}


def modo_de(prefs: dict[str, Any]) -> str:
    if prefs.get("falas_proativas") is False:          # chave antiga, desligada = so o que foi pedido
        return "sob_demanda"
    m = prefs.get("modo_proativo")
    return m if m in PERMITIDAS else "assistido"


def em_silencio(agora: datetime, inicio: int, fim: int) -> bool:
    """Horario de silencio [inicio, fim) em horas; atravessa a meia-noite."""
    if inicio == fim:
        return False
    h = agora.hour
    return inicio <= h < fim if inicio < fim else (h >= inicio or h < fim)


class Anunciador(threading.Thread):
    def __init__(self, falar: Callable[[str], Any], ocupado: Callable[[], bool],
                 prefs: Any, registrar: Callable[[str], None] | None = None) -> None:
        super().__init__(name="anunciador", daemon=True)
        self._falar = falar
        self._ocupado = ocupado
        self._prefs = prefs
        self._registrar = registrar or (lambda t: None)
        self._fila: queue.Queue[tuple[str, bool, float]] = queue.Queue(maxsize=20)
        self._encerrar = threading.Event()

    def anunciar(self, texto: str, pedido_pelo_usuario: bool = False, validade_s: float = 300,
                 categoria: str | None = None) -> bool:
        """Enfileira uma fala. `pedido_pelo_usuario` (lembrete, timer, monitor) fura o silencio."""
        p = self._prefs.ler()
        categoria = "pedido" if pedido_pelo_usuario else (categoria or "observacao")
        if categoria not in PERMITIDAS[modo_de(p)]:
            return False
        if not pedido_pelo_usuario and em_silencio(datetime.now(), int(p.get("silencio_inicio", 22)),
                                                   int(p.get("silencio_fim", 7))):
            return False
        try:
            self._fila.put_nowait((texto, pedido_pelo_usuario, time.time() + validade_s))
            return True
        except queue.Full:
            return False

    def limpar(self) -> int:
        """Descarta as falas na fila ("pare"). Devolve quantas."""
        n = 0
        while True:
            try:
                self._fila.get_nowait()
                n += 1
            except queue.Empty:
                return n

    def encerrar(self) -> None:
        self._encerrar.set()

    def run(self) -> None:
        while not self._encerrar.is_set():
            try:
                texto, _, vence = self._fila.get(timeout=0.5)
            except queue.Empty:
                continue
            while self._ocupado() and not self._encerrar.is_set() and time.time() < vence:
                time.sleep(0.3)                     # espera voce terminar de falar
            if time.time() >= vence or self._encerrar.is_set():
                continue                            # passou da hora: nao fala fora de contexto
            self._registrar(texto)
            try:
                self._falar(texto)
            except Exception:  # noqa: BLE001
                pass
