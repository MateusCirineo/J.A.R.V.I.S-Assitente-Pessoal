"""Memoria do Senhor: o que ele pede para o Jarvis guardar, corrigir ou esquecer.

"Jarvis, lembre que eu prefiro café sem açúcar" / "o que você sabe sobre mim?"
/ "esqueça o café" / "corrija a memória: meu time é o Palmeiras".

Usa o MESMO arquivo de fatos do OpenJarvis ([memory] facts_path, padrao
~/.openjarvis/memory_facts.jsonl), com fonte "hud-voz" e proveniencia
"trusted" (foi o proprio usuario quem disse). Assim o Chat do OpenJarvis ve os
mesmos fatos quando a memoria automatica dele estiver ligada. Esquecer usa
`remove_reviewed` (um fato conferido pelo texto), nunca `clear`; apagar tudo
pede confirmacao falada.

Nao guarda senhas, codigos, tokens ou numeros de cartao.
"""

from __future__ import annotations

import re
import threading
import unicodedata
from typing import Any

FONTE = "hud-voz"
_SEGREDO = re.compile(r"\b(?:senhas?|password|token|pin|cvv|codigo de seguranca|codigo de verificacao|chave (?:da )?api"
                      r"|numero do (?:meu )?cartao|cartao de credito)\b")
_VAZIAS = {"o", "a", "os", "as", "de", "do", "da", "dos", "das", "que", "e", "um", "uma", "eu", "meu", "minha",
           "meus", "minhas", "sobre", "com", "em", "no", "na", "para", "pra", "isso", "esse", "essa", "sou",
           "tenho", "gosto", "prefiro"}


def _norm(t: str) -> str:
    t = unicodedata.normalize("NFKD", t.lower())
    return " ".join("".join(c for c in t if not unicodedata.combining(c)).split())


def palavras(t: str) -> set[str]:
    return {p for p in re.findall(r"\w{3,}", _norm(t)) if p not in _VAZIAS}


def parece_segredo(texto: str) -> bool:
    return bool(_SEGREDO.search(_norm(texto)))


class Memoria:
    def __init__(self, loja: Any = None) -> None:
        self._loja = loja
        self._trava = threading.RLock()

    def loja(self) -> Any:
        with self._trava:
            if self._loja is None:
                from openjarvis.core.config import load_config
                from openjarvis.memory.store import create_fact_store
                mem = load_config().memory
                self._loja = create_fact_store(getattr(mem, "backend", "local"),
                                               path=getattr(mem, "facts_path", None),
                                               max_facts=getattr(mem, "max_facts", 1000))
            return self._loja

    # ---- leitura ----------------------------------------------------------
    def listar(self) -> list[tuple[int, Any]]:
        """(indice no arquivo, fato) dos que podem ir ao modelo, mais novos primeiro."""
        fatos = list(enumerate(self.loja().list()))
        return [(i, f) for i, f in reversed(fatos) if f.trusted_for_recall]

    def para_prompt(self, limite: int = 12, max_chars: int = 700) -> list[str]:
        saida, total = [], 0
        try:
            itens = self.listar()
        except Exception:  # noqa: BLE001 - sem memoria, o Jarvis continua respondendo
            return []
        for _, f in itens[:limite]:
            t = " ".join(f.text.split())[:200]
            if total + len(t) > max_chars:
                break
            saida.append(t)
            total += len(t)
        return saida

    def achar(self, frase: str) -> list[tuple[int, Any]]:
        """Fatos que mais compartilham palavras com a frase (empatados = ambiguo)."""
        alvo = palavras(frase)
        if not alvo:
            return []
        pontos = []
        for i, f in self.listar():
            comum = len(alvo & palavras(f.text))
            if comum:
                pontos.append((comum, i, f))
        if not pontos:
            return []
        melhor = max(p[0] for p in pontos)
        return [(i, f) for c, i, f in pontos if c == melhor]

    # ---- escrita ----------------------------------------------------------
    def guardar(self, texto: str) -> bool:
        if parece_segredo(texto):
            return False
        texto = " ".join(texto.split()).strip(" .")[:300]
        if len(texto) < 3:
            return False
        texto = texto[0].upper() + texto[1:]
        loja = self.loja()
        adicionar = getattr(loja, "add_with_trust", loja.add)
        return bool(adicionar(texto, source=FONTE, trust="trusted"))

    def esquecer(self, indice: int, texto: str) -> bool:
        try:
            return bool(self.loja().remove_reviewed(indice, texto))
        except NotImplementedError:
            return False

    def corrigir(self, novo: str) -> str | None:
        """Troca o fato mais parecido pelo novo. Devolve o texto antigo (ou None)."""
        if parece_segredo(novo):
            return None
        with self._trava:
            achados = self.achar(novo)
            if len(achados) > 1:
                raise ValueError("há mais de uma memória correspondente; indique qual corrigir")
            # Grava antes de excluir: falha de persistência não apaga o fato anterior.
            if not self.guardar(novo):
                return None
            if len(achados) == 1:
                _, f = achados[0]
                # Inserção pode ter alterado índices por limite/remoção concorrente.
                for i, atual in self.listar():
                    if atual.text == f.text and self.esquecer(i, f.text):
                        return f.text
            return None

    def inspecionar(self) -> list[dict[str, Any]]:
        """Proveniência legível; fatos legados não viram confirmação por inferência."""
        return [{"indice": i, "texto": f.text, "fonte": f.source, "data": f.created_at,
                 "proveniencia": f.trust,
                 "tipo": "confirmado_usuario" if f.source == FONTE and f.trust == "trusted" else "registro_legado",
                 "escopo": "memoria_pessoal", "validade": "ate_correcao_ou_exclusao"}
                for i, f in self.listar()]

    def contar(self) -> int:
        return len(self.listar())

    def limpar(self) -> int:
        return int(self.loja().clear())
