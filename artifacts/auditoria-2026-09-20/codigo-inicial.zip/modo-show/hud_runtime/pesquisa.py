"""Pesquisa com fontes: responde citando de onde veio.

Ordem: Wikipedia em portugues (resumo do verbete), DuckDuckGo (resposta
instantanea) e, para assuntos do momento, manchetes do Google Noticias.
Sem fonte encontrada = diz que nao encontrou (nunca inventa). O modelo nao
entra aqui: o texto falado e o proprio resumo da fonte, com o nome dela.

So a consulta sai do computador (para essas APIs publicas); TLS verificado.
"""

from __future__ import annotations

import re
import threading
import time
import urllib.parse
from typing import Any

from .rede import ERROS_REDE, baixar_json

WIKI_BUSCA = "https://pt.wikipedia.org/w/api.php?"
WIKI_RESUMO = "https://pt.wikipedia.org/api/rest_v1/page/summary/"
DDG = "https://api.duckduckgo.com/?"
VALIDADE_S = 30 * 60


def frases(texto: str, n: int = 2, limite: int = 360) -> str:
    """Primeiras n frases, sem cortar no meio de "Dr." ou de numeros."""
    partes = re.split(r"(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÂÊÔÃÕÇ])", " ".join(texto.split()))
    saida = ""
    for p in partes[:n]:
        if len(saida) + len(p) > limite and saida:
            break
        saida = f"{saida} {p}".strip()
    saida = saida[:limite].rstrip(" ,;:")
    return saida if saida.endswith((".", "!", "?")) else saida + "."


def limpar_consulta(q: str) -> str:
    q = " ".join(q.split()).strip(" .!?,;:")
    q = re.sub(r"^(?:sobre|a respeito de|acerca de|por|o que (?:e|é)|quem (?:e|é|foi))\s+", "", q, flags=re.I)
    q = re.sub(r"^(?:o|a|os|as|um|uma)\s+(?=\S)", "", q, flags=re.I)
    return q[:120]


class Pesquisa:
    def __init__(self, noticias=None) -> None:
        self._noticias = noticias
        self._cache: dict[str, tuple[float, dict]] = {}
        self._trava = threading.Lock()

    def wikipedia(self, q: str) -> dict[str, Any] | None:
        busca = baixar_json(WIKI_BUSCA + urllib.parse.urlencode(
            {"action": "query", "list": "search", "srsearch": q, "format": "json", "srlimit": 3}))
        for r in (busca.get("query") or {}).get("search", []):
            titulo = r["title"]
            p = baixar_json(WIKI_RESUMO + urllib.parse.quote(titulo.replace(" ", "_"), safe=""))
            if p.get("type") == "disambiguation" or not p.get("extract"):
                continue
            url = ((p.get("content_urls") or {}).get("desktop") or {}).get("page")
            return {"fonte": "Wikipédia", "titulo": p.get("title") or titulo, "texto": p["extract"],
                    "link": url if isinstance(url, str) and url.startswith("https://") else None}
        return None

    def duckduckgo(self, q: str) -> dict[str, Any] | None:
        d = baixar_json(DDG + urllib.parse.urlencode({"q": q, "format": "json", "no_html": 1, "skip_disambig": 1}))
        texto = d.get("AbstractText") or d.get("Answer")
        if not texto:
            return None
        url = d.get("AbstractURL")
        return {"fonte": d.get("AbstractSource") or "DuckDuckGo", "titulo": d.get("Heading") or q, "texto": str(texto),
                "link": url if isinstance(url, str) and url.startswith("https://") else None}

    def responder(self, consulta: str, com_noticias: bool = True) -> dict[str, Any]:
        q = limpar_consulta(consulta)
        if len(q) < 2:
            return {"status": "vazio", "consulta": q, "fala": "O que devo pesquisar?", "fontes": []}
        chave = q.lower()
        with self._trava:
            g = self._cache.get(chave)
        if g and time.time() - g[0] < VALIDADE_S:
            return g[1]
        principal, falhas = None, []
        for nome, f in (("Wikipédia", self.wikipedia), ("DuckDuckGo", self.duckduckgo)):
            try:
                principal = f(q)
            except (*ERROS_REDE, KeyError) as e:
                falhas.append(f"{nome}: {type(e).__name__}")
            if principal:
                break
        fontes = [principal] if principal else []
        noticias = []
        if com_noticias and self._noticias:
            n = self._noticias.buscar(q, limite=3)
            noticias = n.get("itens", []) if n.get("status") == "medido" else []
            fontes += [{"fonte": x["fonte"], "titulo": x["titulo"], "link": x["link"], "texto": None} for x in noticias]
        if principal:
            fala = f"Segundo a {principal['fonte']}: {frases(principal['texto'])}"
            if noticias:
                fala += f" Nas notícias recentes, {noticias[0]['fonte']}: {noticias[0]['titulo'].rstrip('.')}."
        elif noticias:
            fala = (f"Não achei um verbete sobre {q}, mas há notícias recentes. "
                    f"{noticias[0]['fonte']}: {noticias[0]['titulo'].rstrip('.')}.")
        else:
            fala = f"Não encontrei fontes confiáveis sobre {q}."
            if falhas:
                fala += " As fontes de pesquisa não responderam."
        r = {"status": "medido" if fontes else "sem_fontes", "consulta": q, "fala": fala, "fontes": fontes,
             "falhas": falhas, "em": time.time()}
        if fontes:
            with self._trava:
                self._cache[chave] = (time.time(), r)
        return r


def cartao(r: dict[str, Any]) -> dict[str, Any]:
    itens = [{"titulo": f["titulo"], "detalhe": frases(f["texto"], 1, 180) if f.get("texto") else None,
              "fonte": f["fonte"], "link": f.get("link")} for f in r.get("fontes", [])]
    return {"tipo": "pesquisa", "titulo": f"Pesquisa: {r.get('consulta', '')}", "itens": itens}
