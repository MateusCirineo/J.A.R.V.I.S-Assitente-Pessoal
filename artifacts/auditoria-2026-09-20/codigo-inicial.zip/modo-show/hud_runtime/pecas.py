"""Peças com parâmetros e versões -- não só um STL solto.

Antes disto o Jarvis gerava a malha, salvava o arquivo e esquecia tudo: não dava
para dizer "aumente dois milímetros" nem "volte para a de ontem", porque a peça
não existia em lugar nenhum depois de salva. Aqui ficam os parâmetros de origem,
cada versão e o que foi medido de fato (§12 do prompt mestre de 19/09).

Três regras:

1. **Alterar não apaga.** Cada mudança cria uma versão nova; a anterior continua
   no disco e dá para voltar.
2. **O que eu digo foi medido.** O volume sai da malha gerada, não de uma conta
   de guardanapo. Se eu não conferi, eu digo que não conferi.
3. **STL salvo não é peça pronta para imprimir.** A validação aqui vê unidades,
   valores impossíveis, relações entre dimensões e espessura mínima -- e só.
"""

from __future__ import annotations

import json
import os
import threading
import time
import unicodedata
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

HOME = Path(os.environ.get("OPENJARVIS_HOME", Path.home() / ".openjarvis"))
ARQ = HOME / "hud-pecas.json"

# bico comum de 0,4 mm: abaixo de 0,8 a parede sai com um perimetro so e quebra
PAREDE_MINIMA_MM = 0.8
MAIOR_MM = 300.0            # mesa da maioria das impressoras caseiras

# como o Senhor fala cada dimensao, por tipo de peca
DIMENSOES: dict[str, dict[str, str]] = {
    "caixa": {"comprimento": "c", "largura": "l", "altura": "a", "parede": "parede",
              "espessura": "parede", "profundidade": "l"},
    "cilindro": {"diametro": "diametro", "altura": "altura"},
    "tubo": {"externo": "externo", "interno": "interno", "altura": "altura",
             "diametro externo": "externo", "diametro interno": "interno", "furo": "interno"},
    "esfera": {"diametro": "diametro"},
    "cone": {"diametro": "diametro", "altura": "altura", "base": "diametro"},
    "engrenagem": {"dentes": "dentes", "externo": "externo", "diametro": "externo",
                   "espessura": "espessura", "furo": "furo"},
    # montagem que o Jarvis sabe fazer inteira (ver montagem.py): da para explodir
    "caixa_com_tampa": {"comprimento": "c", "largura": "l", "altura": "a", "parede": "parede",
                        "tampa": "tampa", "espessura da tampa": "tampa", "profundidade": "l"},
}
MONTAGENS = ("caixa_com_tampa",)      # tipos com componentes conhecidos (F20)
NOME_FALADO = {"c": "comprimento", "l": "largura", "a": "altura", "parede": "parede",
               "diametro": "diâmetro", "altura": "altura", "externo": "diâmetro externo",
               "interno": "diâmetro interno", "dentes": "dentes", "espessura": "espessura",
               "furo": "furo"}


def _norm(texto: str) -> str:
    t = unicodedata.normalize("NFKD", (texto or "").lower())
    return " ".join("".join(c for c in t if not unicodedata.combining(c)).split())


def dimensao_citada(tipo: str, frase: str) -> str | None:
    """"aumente a largura" -> "l". Devolve None quando ele não disse qual."""
    n = _norm(frase)
    mapa = DIMENSOES.get(tipo, {})
    # nome mais longo primeiro: "diametro externo" ganha de "diametro"
    for falado in sorted(mapa, key=len, reverse=True):
        if _norm(falado) in n:
            return mapa[falado]
    return None


def dimensoes_do_tipo(tipo: str) -> list[str]:
    """Nomes falados, sem repetir o mesmo parâmetro (para perguntar ao Senhor)."""
    vistos: dict[str, str] = {}
    for falado, chave in DIMENSOES.get(tipo, {}).items():
        vistos.setdefault(chave, falado)
    return list(vistos.values())


@dataclass
class Versao:
    numero: int
    parametros: dict[str, float]
    arquivo: str = ""
    volume_mm3: float = 0.0          # medido na malha gerada, nao estimado
    triangulos: int = 0
    motivo: str = ""                 # o que mudou nesta versao
    em: float = 0.0


@dataclass
class Peca:
    nome: str
    tipo: str
    parametros: dict[str, float]
    projeto: str = ""
    material: str = "PLA"
    versoes: list[Versao] = field(default_factory=list)
    criada_em: float = 0.0
    mexida_em: float = 0.0

    @property
    def versao(self) -> int:
        return self.versoes[-1].numero if self.versoes else 0

    def atual(self) -> Versao | None:
        return self.versoes[-1] if self.versoes else None


def validar(tipo: str, p: dict[str, float]) -> tuple[list[str], list[str]]:
    """(erros que impedem, avisos que só alertam). Só o que dá para conferir de fato."""
    erros: list[str] = []
    avisos: list[str] = []
    for chave, valor in p.items():
        if chave == "parede" and valor == 0:
            continue                                  # 0 = maciça, é opção
        if valor <= 0:
            erros.append(f"{NOME_FALADO.get(chave, chave)} não pode ser {valor:g}")
        elif valor > MAIOR_MM and chave != "dentes":
            avisos.append(f"{NOME_FALADO.get(chave, chave)} de {valor:g} mm não cabe na mesa da impressora")
    if tipo == "tubo" and p.get("interno", 0) >= p.get("externo", 0):
        erros.append("o diâmetro interno precisa ser menor que o externo")
    if tipo == "engrenagem":
        if p.get("dentes", 0) < 6:
            erros.append("uma engrenagem precisa de pelo menos 6 dentes")
        if p.get("furo", 0) >= p.get("externo", 0) * 0.8:
            erros.append("o furo está grande demais para o diâmetro da engrenagem")
    if tipo == "caixa_com_tampa":
        if (p.get("tampa") or 0) <= 0:
            erros.append("a tampa precisa de uma espessura maior que zero")
        elif p.get("tampa", 0) >= p.get("a", 0):
            erros.append("a tampa ficaria mais alta que a própria caixa")
    if tipo in ("caixa", "caixa_com_tampa"):
        parede = p.get("parede") or 0
        if parede:
            menor = min(p.get("c", 0), p.get("l", 0), p.get("a", 0))
            if parede * 2 >= menor:
                erros.append("a parede não cabe: seria maior que metade da menor dimensão")
            elif parede < PAREDE_MINIMA_MM:
                avisos.append(f"parede de {parede:g} mm é fina para um bico de 0,4; "
                              f"abaixo de {PAREDE_MINIMA_MM:g} costuma quebrar")
    return erros, avisos


class Pecas:
    """Peças do Senhor, com histórico. Uma instância por runtime."""

    def __init__(self, arquivo: Path | str | None = None, pasta: Path | None = None) -> None:
        self._arq = Path(arquivo) if arquivo else ARQ
        self._pasta = pasta
        self._trava = threading.RLock()
        self._pecas: dict[str, Peca] = {}
        self._ativa: str | None = None
        self._carregar()

    # ---- disco ----------------------------------------------------------
    def _carregar(self) -> None:
        try:
            d = json.loads(self._arq.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        for bruta in d.get("pecas", []):
            try:
                versoes = [Versao(**v) for v in bruta.pop("versoes", [])]
                self._pecas[_norm(bruta["nome"])] = Peca(versoes=versoes, **bruta)
            except (TypeError, KeyError):
                continue
        self._ativa = d.get("ativa")

    def salvar(self) -> None:
        with self._trava:
            dados = {"pecas": [asdict(p) for p in self._pecas.values()],
                     "ativa": self._ativa, "em": time.time()}
        try:
            self._arq.parent.mkdir(parents=True, exist_ok=True)
            tmp = self._arq.with_suffix(".tmp")
            tmp.write_text(json.dumps(dados, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self._arq)
        except OSError:
            pass

    def pasta(self) -> Path:
        from .cad import pasta_projetos
        return self._pasta or pasta_projetos()

    # ---- criar e achar --------------------------------------------------
    def criar(self, tipo: str, parametros: dict[str, float], *, nome: str = "",
              projeto: str = "", material: str = "PLA", motivo: str = "primeira versão") -> tuple[Peca, list[str]]:
        erros, avisos = validar(tipo, parametros)
        if erros:
            raise ValueError("; ".join(erros))
        agora = time.time()
        with self._trava:
            p = Peca(nome=nome or tipo, tipo=tipo, parametros=dict(parametros), projeto=projeto,
                     material=material, criada_em=agora, mexida_em=agora)
            chave = _norm(p.nome)
            n = 2
            while chave in self._pecas:                 # "caixa", "caixa 2"...
                p.nome = f"{nome or tipo} {n}"
                chave, n = _norm(p.nome), n + 1
            self._pecas[chave] = p
            self._ativa = chave
        self._gerar_versao(p, motivo)
        self.salvar()
        return p, avisos

    def ativa(self) -> Peca | None:
        return self._pecas.get(self._ativa or "")

    def focar(self, nome: str) -> Peca | None:
        p = self.achar(nome)
        if p is not None:
            self._ativa = _norm(p.nome)
            self.salvar()
        return p

    def achar(self, texto: str) -> Peca | None:
        alvo = _norm(texto)
        if not alvo:
            return None
        if alvo in self._pecas:
            return self._pecas[alvo]
        for chave, p in sorted(self._pecas.items(), key=lambda kv: kv[1].mexida_em, reverse=True):
            if alvo in chave or chave in alvo or _norm(p.tipo) == alvo:
                return p
        return None

    def todas(self) -> list[Peca]:
        return sorted(self._pecas.values(), key=lambda p: p.mexida_em, reverse=True)

    # ---- gerar e alterar -------------------------------------------------
    def _gerar_versao(self, p: Peca, motivo: str) -> Versao:
        """Gera a malha AGORA e mede o volume nela. Nada é prometido sem medir."""
        from .cad import salvar_stl, volume_mm3
        from .engenharia import gerar_peca
        if p.tipo in MONTAGENS:
            tris, nome_curto = self._malha_da_montagem(p), p.nome
        else:
            tris, nome_curto, _desc = gerar_peca(p.tipo, p.parametros)
        numero = p.versao + 1
        arquivo = self.pasta() / f"{_norm(p.nome).replace(' ', '_')}_v{numero}.stl"
        try:
            salvar_stl(tris, arquivo, nome_curto)
            caminho = str(arquivo)
        except OSError:
            caminho = ""                       # sem disco: a versao existe, o arquivo nao
        v = Versao(numero=numero, parametros=dict(p.parametros), arquivo=caminho,
                   volume_mm3=abs(volume_mm3(tris)), triangulos=len(tris), motivo=motivo,
                   em=time.time())
        with self._trava:
            p.versoes.append(v)
            p.mexida_em = time.time()
        return v

    @staticmethod
    def montagem_de(p: Peca):
        """A montagem (com componentes) por trás de uma peça composta."""
        from .montagem import caixa_com_tampa
        if p.tipo == "caixa_com_tampa":
            q = p.parametros
            return caixa_com_tampa(q["c"], q["l"], q["a"], q.get("parede", 2.0), q.get("tampa", 2.0))
        return None

    def _malha_da_montagem(self, p: Peca, explodir: float = 0.0):
        from .montagem import malha
        m = self.montagem_de(p)
        if m is None:
            raise ValueError(f"{p.tipo} não é uma montagem conhecida")
        return malha(m, explodir)

    def explodir(self, p: Peca, fator: float = 1.0):
        """STL com as peças separadas, para a mesa. Só de montagem conhecida."""
        from .cad import salvar_stl
        tris = self._malha_da_montagem(p, fator)
        arquivo = self.pasta() / f"{_norm(p.nome).replace(' ', '_')}_v{p.versao}_explodida.stl"
        try:
            salvar_stl(tris, arquivo, f"{p.nome} explodida")
        except OSError:
            return None
        return arquivo

    def alterar(self, p: Peca, chave: str, *, valor: float | None = None,
                delta: float | None = None, motivo: str = "") -> tuple[Versao, list[str]]:
        """Muda UMA dimensão e gera outra versão. A anterior continua intacta."""
        if chave not in p.parametros:
            raise KeyError(f"{p.tipo} não tem {NOME_FALADO.get(chave, chave)}")
        antes = p.parametros[chave]
        novo = float(valor) if valor is not None else antes + float(delta or 0)
        candidatos = dict(p.parametros)
        candidatos[chave] = novo
        erros, avisos = validar(p.tipo, candidatos)
        if erros:
            raise ValueError("; ".join(erros))
        nome = NOME_FALADO.get(chave, chave)
        with self._trava:
            p.parametros = candidatos
        v = self._gerar_versao(p, motivo or f"{nome} de {antes:g} para {novo:g} mm")
        self.salvar()
        return v, avisos

    def reverter(self, p: Peca, numero: int) -> Versao | None:
        """Volta os parâmetros de uma versão antiga -- criando uma versão nova."""
        alvo = next((v for v in p.versoes if v.numero == numero), None)
        if alvo is None:
            return None
        with self._trava:
            p.parametros = dict(alvo.parametros)
        v = self._gerar_versao(p, f"voltou para a versão {numero}")
        self.salvar()
        return v

    def esquecer(self, nome: str) -> bool:
        with self._trava:
            chave = _norm(nome)
            saiu = self._pecas.pop(chave, None) is not None
            if self._ativa == chave:
                self._ativa = None
        if saiu:
            self.salvar()
        return saiu


# ---- como o Jarvis fala disso -------------------------------------------
def _num(x: float) -> str:
    return f"{x:.10g}".replace(".", ",")


def descrever(p: Peca) -> str:
    """"caixa 80 por 50 por 30 milímetros, parede 2" -- do jeito que se fala."""
    itens = [f"{NOME_FALADO.get(k, k)} {_num(v)}" for k, v in p.parametros.items() if v]
    return f"{p.tipo} com " + ", ".join(itens) if itens else p.tipo


def falar_versao(p: Peca, v: Versao, avisos: list[str] | None = None,
                 tratamento: str = "Senhor") -> str:
    """O que mudou, o que foi medido e o que NÃO foi conferido."""
    cm3 = v.volume_mm3 / 1000
    frases = [f"Versão {v.numero} de {p.nome}: {v.motivo}"]
    frases.append(f"Medi na peça gerada: {_num(round(cm3, 1))} centímetros cúbicos, "
                  f"uns {_num(round(cm3 * 1.24, 1))} gramas em PLA maciço")
    if v.numero > 1:
        frases.append(f"A versão {v.numero - 1} continua salva; para voltar, diga: "
                      f"volte para a versão {v.numero - 1}")
    for a in (avisos or []):
        frases.append(f"Atenção: {a}")
    frases.append("Não testei impressão: isso só o Cura e a impressora dizem")
    return ". ".join(frases) + "."


def falar_versoes(p: Peca, tratamento: str = "Senhor") -> str:
    if not p.versoes:
        return f"{p.nome} ainda não tem versão salva, {tratamento}."
    linhas = [f"versão {v.numero}, {v.motivo}" for v in p.versoes[-5:]]
    return f"{p.nome} está na versão {p.versao}, {tratamento}: " + "; ".join(linhas) + "."
