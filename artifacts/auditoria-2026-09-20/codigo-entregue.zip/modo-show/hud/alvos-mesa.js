// A peça ativa só é o alvo se for também o artefato exibido nesta tela.
export function alvoDaMesa(modelo, peca, apresentacao) {
  const caminho = (valor) => typeof valor === 'string' ? valor.replace(/\\/g, '/').toLowerCase() : '';
  const mesmaPeca = Boolean(modelo && peca?.nome && peca.arquivo && apresentacao?.id &&
    apresentacao.id === modelo.apresentacaoId && caminho(peca.arquivo) === caminho(apresentacao.arquivo));
  return { tipo: mesmaPeca ? 'peca' : 'regiao', id: mesmaPeca ? peca.nome : 'mesa-3d',
    rotulo: mesmaPeca ? peca.nome : modelo?.nome || 'Visualização 3D',
    caixa: [0.27, 0.1, 0.46, 0.65], extra: { fonte: 'mesa' } };
}
