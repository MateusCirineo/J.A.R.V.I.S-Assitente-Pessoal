"""Protocolos: sequencias de comandos com nome, como nos filmes ("Jarvis, protocolo
casa"). O Senhor cria por voz ("crie o protocolo trabalho: abra o VS Code, abra o
Gmail e me dê as notícias de tecnologia"), executa ("execute o protocolo trabalho")
e pode agendar ("todo dia às 8h execute o protocolo trabalho").

Cada passo precisa ser um comando que o Jarvis ja conhece (nada vai ao modelo) e
comandos destrutivos NUNCA entram num protocolo nem numa rotina agendada: apagar
memoria, quarentena, limpar listas, cancelar lembretes, descanso/desligar, gerar
programas. Guardados em ~/.openjarvis/hud-protocolos.json.
"""

from __future__ import annotations

import json
import os
import re
import threading
import unicodedata
from pathlib import Path
from typing import Callable

HOME = Path(os.environ.get("OPENJARVIS_HOME", Path.home() / ".openjarvis"))

# o que NUNCA roda sozinho (protocolo ou horario marcado)
PROIBIDOS = {
    "confirmar_acao", "memoria_limpar", "memoria_limpar_confirmado", "memoria_esquecer", "memoria_corrigir",
    "quarentena_confirmar", "quarentena_mover", "quarentena_restaurar", "varredura", "lista_limpar",
    "lembretes_cancelar", "lembrete_remarcar", "rotina_descanso", "programa", "planilha", "despedida",
    "parar_fala", "protocolo_criar", "protocolo_apagar", "agendar", "notas_apagar",
}
MAX_PASSOS = 10


def _norm(t: str) -> str:
    t = unicodedata.normalize("NFKD", t.lower())
    return " ".join("".join(c for c in t if not unicodedata.combining(c)).split()).strip(" .!?,:;")


def nome_protocolo(texto: str) -> str:
    n = _norm(texto)
    return re.sub(r"^(?:o|do|da|de|chamado)\s+", "", n)[:40]


def separar_passos(texto: str) -> list[str]:
    """ "abra o VS Code, abra o Gmail e me dê as notícias" -> 3 passos.
    Separa por virgula, ";", " e depois ", " depois " e pelo " e " antes de um verbo."""
    partes = re.split(r"\s*(?:,|;|\be depois\b|\bdepois\b|\bem seguida\b|\be entao\b)\s*", texto.strip(" ."))
    passos: list[str] = []
    for p in partes:
        p = p.strip(" .")
        if not p:
            continue
        # " e " seguido de verbo no imperativo ("... e me dê", "... e abra", "... e toque") = outro passo
        sub = re.split(r"\s+e\s+(?=(?:me |o |a )?(?:abr|toqu|toc|lig|deslig|ativ|desativ|mostr|diga|d[eê]|leia|fal|"
                       r"coloqu|pon|aument|diminu|mud|execut|inici|abaix|suba|baix|paus|continu)\w*)", p, flags=re.I)
        passos.extend(s.strip(" .") for s in sub if s.strip(" ."))
    return passos


class Protocolos:
    def __init__(self, arquivo: Path = HOME / "hud-protocolos.json") -> None:
        self._arquivo = arquivo
        self._trava = threading.Lock()

    def _ler(self) -> dict[str, list[str]]:
        try:
            d = json.loads(self._arquivo.read_text(encoding="utf-8"))
            return {k: v for k, v in d.items() if isinstance(v, list)} if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def _gravar(self, d: dict[str, list[str]]) -> None:
        self._arquivo.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._arquivo.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, self._arquivo)

    def nomes(self) -> list[str]:
        return sorted(self._ler())

    def passos(self, nome: str) -> list[str] | None:
        return self._ler().get(nome_protocolo(nome))

    def salvar(self, nome: str, passos: list[str]) -> None:
        with self._trava:
            d = self._ler()
            d[nome_protocolo(nome)] = passos[:MAX_PASSOS]
            self._gravar(d)

    def apagar(self, nome: str) -> bool:
        with self._trava:
            d = self._ler()
            if d.pop(nome_protocolo(nome), None) is None:
                return False
            self._gravar(d)
            return True


def validar_passos(passos: list[str], interpretar: Callable[[str], tuple[str, dict] | None]) -> tuple[list[str], str | None]:
    """Todos os passos precisam ser comandos conhecidos e permitidos. Devolve (passos, erro)."""
    if not passos:
        return [], "Não entendi os passos. Diga, por exemplo: crie o protocolo trabalho: abra o VS Code e me dê as notícias."
    if len(passos) > MAX_PASSOS:
        return [], f"No máximo {MAX_PASSOS} passos por protocolo."
    for p in passos:
        achado = interpretar(p)
        if achado is None:
            return [], f"Não sei executar sozinho o passo \"{p}\". Use comandos que eu já conheço."
        if achado[0] in PROIBIDOS:
            return [], f"O passo \"{p}\" não pode rodar sozinho, por segurança."
    return passos, None
