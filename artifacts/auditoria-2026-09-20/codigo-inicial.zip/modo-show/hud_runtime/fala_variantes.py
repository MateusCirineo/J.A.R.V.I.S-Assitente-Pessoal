"""O que o Senhor disse != o que as regras esperam.

Dois problemas reais de 19/09:

1. "Jarvis, memore o meu rosto" nao casou com nenhuma regra (elas esperavam
   "memoriz..."), foi parar no modelo -- que nao sabia do cadastro de rostos e
   RECUSOU. Aqui ficam as variantes da fala do dia a dia; `corrigir()` so vale
   se a frase corrigida casar com alguma regra (quem decide e o chamador).

2. "Jarvis, que horas sao? Jarvis, me lembre de ligar" chegou como UMA frase
   (duas falas grudadas pelo microfone) e virou um lembrete com o texto errado.
   `separar_pedidos()` quebra a frase onde o Senhor chama o Jarvis de novo.

Nada aqui adivinha intencao: sao trocas de palavra por palavra, cada uma com o
motivo ao lado.
"""

from __future__ import annotations

import re

# (regra, troca). O texto ja chega normalizado (minusculo, sem acento) quando
# vem de interpretar(); as regras abaixo funcionam nos dois casos.
VARIANTES: list[tuple[re.Pattern[str], str]] = [
    # "memore/memora/memoriza/memorizar" -> "memorize" (sem tocar em "memoria")
    (re.compile(r"\bmemor(?!ia|ias|izar\b)\w*\b", re.I), "memorize"),
    (re.compile(r"\bmemorizar\b", re.I), "memorize"),
    # "decore o meu rosto", "decora minha voz"
    (re.compile(r"\bdecor(?:e|a|ar|ou)\b", re.I), "memorize"),
    # "cadastra/cadastrar", "registra", "guarda", "salva", "grava" no imperativo falado
    (re.compile(r"\bcadastr(?:a|ar)\b", re.I), "cadastre"),
    (re.compile(r"\bregistr(?:a|ar)\b", re.I), "registre"),
    # a cara / a minha face -> rosto (so depois de um verbo de cadastro)
    (re.compile(r"\b(memorize|cadastre|registre|grave|guarde|salve|aprenda)\s+"
                r"(?:a\s+|minha\s+|a\s+minha\s+|o\s+meu\s+)?(?:cara|face|fisionomia)\b", re.I), r"\1 o meu rosto"),
    # "aprende", "aprenda a reconhecer" -> aprenda
    (re.compile(r"\baprend(?:e|er)\b", re.I), "aprenda"),
    # "se lembra de mim?" nao entra aqui de proposito: e pergunta, nao cadastro.
    # "quem ta ai", "quem que ta aqui" (com e sem acento: a fala chega dos dois jeitos)
    (re.compile(r"\bquem que (?:esta|está|ta|tá|e|é)\b", re.I), "quem esta"),
    # verbos de acao que a transcricao costuma trazer no infinitivo
    (re.compile(r"\bmedir\b", re.I), "meca"),
    (re.compile(r"\besquecer\b", re.I), "esqueca"),
    (re.compile(r"\bapagar\b", re.I), "apague"),
    (re.compile(r"\babrir\b", re.I), "abra"),
    (re.compile(r"\bdesligar\b", re.I), "desligue"),
    (re.compile(r"\bligar\b(?!\s+(?:para|pra|pro)\b)", re.I), "ligue"),
]

_CHAMADO = r"(?:jarvis|jarbas|jarvas|jervis|djarvis)"
# o Senhor chamando o Jarvis DE NOVO no meio da frase = comecou outro pedido
_OUTRO_PEDIDO = re.compile(rf"(?<=.)[\s,.;!?]+{_CHAMADO}\b[\s,]*", re.I)


def corrigir(texto: str) -> str:
    """Troca as variantes conhecidas. Pode devolver o proprio texto."""
    saida = texto
    for regra, troca in VARIANTES:
        saida = regra.sub(troca, saida)
    return saida


def mudou(texto: str) -> bool:
    return corrigir(texto) != texto


def separar_pedidos(texto: str) -> list[str]:
    """Duas falas grudadas viram dois pedidos; uma fala so continua inteira.

    "Jarvis, que horas sao? Jarvis, me lembre de ligar" ->
    ["Jarvis, que horas sao?", "me lembre de ligar"]
    """
    t = (texto or "").strip()
    if not t:
        return []
    partes = [p.strip(" ,.;") for p in _OUTRO_PEDIDO.split(t)]
    partes = [p for p in partes if len(p) >= 3]
    return partes or [t]
